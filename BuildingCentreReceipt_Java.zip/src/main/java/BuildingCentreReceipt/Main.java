package BuildingCentreReceipt;


/**
 * Demo application of the buildin centre.
 */
public class Main {
	/**
	 * Demonstrates the principle use of the classes of the building centre.<br>
	 * In main you
	 * 
	 * <ol>
	 * <li>create and display the receipt text for the shopping cart</li>
	 * <li>print the receipt to file "BuildingCentreReceipt"</li>
	 * <li>filter the shopping cart with search term "Brick"</li>
	 * <li>sort the shoppingcart by name and display again</li>
	 * </ol>
	 * 
	 * 
	 */
	public static void main(String[] args) {

		List<BuildingCentreProductBase> shoppingCart;
		shoppingCart = new LinkedList<>();
		shoppingCart.add(new Tool("Hammer", 10.99, 2));
		shoppingCart.add(new Tool("Shovel", 23.5, 5));
		shoppingCart.add(new CraftsmanSupport("Bricklayer", 12, 85.875));
		shoppingCart.add(new Material("Brick", "Gate 23", 2.5, 45));
		shoppingCart.add(new Material("Cement bag", "Gate 27", 2.5, 345));
		// ---------------------------- YOUR CODE HERE ---------------------------

		
		// create and display the receipt text
		// print the receipt to file "BuildingCentreReceipt"
		// filter the shopping cart with search term "Brick"
		// sort the filtered shoppingcart by name and display again
		// -----------------------------------------------------------------------

		

		
	}

	// ---------------------------- YOUR CODE HERE ---------------------------

	
	// -----------------------------------------------------------------------

}